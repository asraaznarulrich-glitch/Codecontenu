import { i as __toESM } from "./_runtime.mjs";
import { i as nextProject, n as getProject } from "./_ssr/site-hychIQvj.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as ArrowRight, o as ArrowLeft } from "./_libs/lucide-react.mjs";
import { n as Route } from "./_ssr/router-CNDCah2J.mjs";
import { n as SiteFooter, r as SiteHeader, t as ContactForm } from "./_ssr/site-header-jTbAgO-B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-06s9E1Gu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SpecimenFrame({ kind, label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-line bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-muted",
				children: kind
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: label
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-4 sm:p-6",
			children
		})]
	});
}
function ProjectSpecimen({ specimen }) {
	if (specimen === "sillon") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sillon, {});
	if (specimen === "cahier") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cahier, {});
	if (specimen === "seuil") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seuil, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comptoir, {});
}
function Sillon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecimenFrame, {
		kind: "Lecture",
		label: "Sillon · numéro 04",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-oxide",
				children: "Essai · 8 min"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-serif text-3xl leading-tight sm:text-4xl",
				children: "Ce qu’une marge peut encore porter"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Note de lecture · Codecontenu"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "drop-cap mt-6 font-serif text-lg leading-relaxed",
				children: "Une revue n’a pas besoin d’occuper tout l’écran. Elle a besoin d’un rythme : un titre qui se lit d’un coup, un paragraphe qui ne se casse pas au milieu d’une idée, et, sur un grand écran, une marge assez large pour une note sans renvoyer le lecteur ailleurs."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "mt-6 border-l-2 border-oxide pl-4 font-serif text-lg italic leading-snug",
				children: "« Le temps de lecture affiché vient du texte, pas d’une moyenne inventée. »"
			})
		] })
	});
}
var columnLabel = {
	write: "À écrire",
	review: "En relecture",
	live: "Publié"
};
var initialCards = [
	{
		id: "marges",
		title: "Ce qu’une marge peut encore porter",
		column: "review"
	},
	{
		id: "sommaire",
		title: "Sommaire du numéro 04",
		column: "write"
	},
	{
		id: "charte",
		title: "Feuille typographique",
		column: "live"
	},
	{
		id: "accueil",
		title: "Page du numéro, version 2",
		column: "write"
	}
];
function Cahier() {
	const [cards, setCards] = (0, import_react.useState)(initialCards);
	function move(id, direction) {
		const order = [
			"write",
			"review",
			"live"
		];
		setCards((current) => current.map((card) => {
			if (card.id !== id) return card;
			const next = order.indexOf(card.column) + direction;
			if (next < 0 || next >= order.length) return card;
			return {
				...card,
				column: order[next] ?? card.column
			};
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecimenFrame, {
		kind: "Suivi",
		label: "Cahier · Sillon",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 lg:grid-cols-3",
			children: Object.keys(columnLabel).map((column) => {
				const items = cards.filter((card) => card.column === column);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": columnLabel[column],
					className: "bg-paper",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-baseline justify-between border-b border-line pb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-serif text-xl",
							children: columnLabel[column]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm tabular-nums text-muted",
							children: items.length
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-3",
						children: items.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border border-line p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-snug",
								children: card.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 flex-1 border border-line px-2 text-xs disabled:cursor-not-allowed disabled:text-muted",
									disabled: card.column === "write",
									onClick: () => move(card.id, -1),
									children: "Reculer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 flex-1 bg-ink px-2 text-xs text-paper disabled:cursor-not-allowed disabled:bg-line disabled:text-muted",
									disabled: card.column === "live",
									onClick: () => move(card.id, 1),
									children: "Avancer"
								})]
							})]
						}, card.id))
					})]
				}, column);
			})
		})
	});
}
function Seuil() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecimenFrame, {
		kind: "Lancement",
		label: "Seuil · Sillon",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-8 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-oxide",
					children: "Revue en ligne"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 font-serif text-4xl leading-none",
					children: "Sillon, pour les textes qui prennent le temps."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-6 flex flex-col gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-line pt-3",
							children: "Un gabarit de lecture, pas un thème généraliste."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-line pt-3",
							children: "Des numéros, un sommaire, des notes de marge."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-t border-line pt-3",
							children: "Le même article reste lisible sur un téléphone."
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {
				subject: "Sillon — demande",
				intro: "Pour recevoir le prochain numéro, écrivez. Le message part depuis votre messagerie."
			})]
		})
	});
}
var offers = [
	{
		title: "Page",
		fit: "Une offre, un public, une action.",
		includes: [
			"Récit",
			"Mise en page",
			"Formulaire"
		],
		excludes: "Pas de site complet."
	},
	{
		title: "Site",
		fit: "Plusieurs pages, un ton, une navigation.",
		includes: [
			"Structure",
			"Textes",
			"Intégration"
		],
		excludes: "Pas de boutique, sauf si elle est dans le périmètre."
	},
	{
		title: "Outil",
		fit: "Un geste de travail, répété chaque semaine.",
		includes: [
			"Parcours",
			"Écrans",
			"États"
		],
		excludes: "Pas une suite logicielle."
	}
];
function Comptoir() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpecimenFrame, {
		kind: "Brief",
		label: "Comptoir",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-3",
			children: offers.map((offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "flex flex-col border border-line p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-2xl",
						children: offer.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: offer.fit
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-1 text-sm",
						children: offer.includes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 border-t border-line pt-3 text-sm text-muted",
						children: offer.excludes
					})
				]
			}, offer.title))
		})
	});
}
function ProjectPage() {
	const { slug } = Route.useParams();
	const project = getProject(slug);
	if (!project) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto flex min-h-[70vh] max-w-6xl flex-col justify-center px-5 py-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-oxide",
					children: "Introuvable"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-serif text-5xl",
					children: "Ce projet n’est pas dans le studio."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					hash: "projets",
					className: "mt-8 inline-flex min-h-11 items-center text-sm underline",
					children: "Retour aux projets"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
	] });
	const following = nextProject(project.slug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-5 pt-10 pb-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					hash: "projets",
					className: "inline-flex min-h-11 items-center gap-2 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Projets"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 font-serif text-2xl text-oxide",
					children: project.index
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid gap-8 lg:grid-cols-12 lg:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-serif text-6xl leading-none sm:text-8xl lg:col-span-7",
						children: project.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg lg:col-span-5",
						children: project.summary
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-10 grid gap-6 border-y border-line py-6 sm:grid-cols-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs uppercase tracking-widest text-muted",
						children: "Disciplines"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-2",
						children: project.disciplines.join(" · ")
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs uppercase tracking-widest text-muted",
							children: "Rôle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-2",
							children: project.role
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-14 grid gap-12 lg:grid-cols-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-8 lg:col-span-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-3xl",
								children: "Situation"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-muted",
								children: project.situation
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-3xl",
								children: "Façon de faire"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-muted",
								children: project.approach
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-serif text-3xl",
								children: "Livré"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3",
								children: project.delivered.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "border-t border-line py-2 text-sm",
									children: item
								}, item))
							})] })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:col-span-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectSpecimen, { specimen: project.specimen })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/projets/$slug",
					params: { slug: following.slug },
					className: "mt-16 flex items-center justify-between gap-4 border-t border-ink pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs uppercase tracking-widest text-muted",
						children: "Projet suivant"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block font-serif text-3xl",
						children: [
							following.index,
							" ",
							following.title
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-5" })]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
	] });
}
//#endregion
export { ProjectPage as component };
