//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BVGxOboO.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/projets/$slug"],
		preloads: ["/assets/index-MQxWkDld.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-MQxWkDld.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DFsK2imP.js", "/assets/site-header-DjTBbrpb.js"]
	},
	"/projets/$slug": {
		filePath: "/workspace/src/routes/projets/$slug.tsx",
		children: void 0,
		preloads: ["/assets/_slug-CxpScsax.js", "/assets/site-header-DjTBbrpb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
