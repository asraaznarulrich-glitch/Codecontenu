import { i as __toESM } from "../_runtime.mjs";
import { a as practice, o as projects, r as method, s as studio, t as disciplines } from "./site-hychIQvj.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { n as SiteFooter, r as SiteHeader, t as ContactForm } from "./site-header-jTbAgO-B.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BMLiXns-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const [filter, setFilter] = (0, import_react.useState)("Tous");
	const visible = (0, import_react.useMemo)(() => filter === "Tous" ? projects : projects.filter((project) => project.disciplines.includes(filter)), [filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#contenu",
			className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:bg-ink focus:px-3 focus:py-2 focus:text-paper",
			children: "Aller au contenu"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "contenu",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto grid max-w-6xl gap-10 px-5 pt-14 pb-16 sm:pt-20 lg:grid-cols-12 lg:pt-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lg:col-span-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-oxide",
							children: studio.eyebrow
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-4 font-serif text-6xl leading-none sm:text-8xl lg:text-9xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block",
								children: "Code"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block italic text-oxide",
								children: "contenu"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-end gap-6 lg:col-span-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg leading-relaxed",
							children: studio.description
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								hash: "projets",
								className: "inline-flex min-h-11 items-center justify-center bg-ink px-5 text-sm text-paper",
								children: "Voir les projets"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								hash: "contact",
								className: "inline-flex min-h-11 items-center justify-center border border-ink px-5 text-sm",
								children: "Décrire un besoin"
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "studio",
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-10 px-5 py-16 lg:grid-cols-12 lg:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-muted",
								children: "Studio"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-serif text-4xl leading-tight sm:text-5xl",
								children: "Un interlocuteur, un périmètre, un livrable qu’on ouvre dans un navigateur."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-5 lg:col-span-7 lg:col-start-6",
							children: [studio.about.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg leading-relaxed",
								children: paragraph
							}, paragraph)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid gap-8 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Practice, {
									title: "Code",
									items: practice.code
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Practice, {
									title: "Contenu",
									items: practice.contenu
								})]
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "projets",
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-5 py-16 lg:py-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "max-w-xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs uppercase tracking-widest text-muted",
											children: "Projets"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "mt-3 font-serif text-4xl leading-tight sm:text-5xl",
											children: "Les pièces du studio."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-muted",
											children: "Quatre travaux menés par Codecontenu : une revue, l’outil qui la produit, sa page de lancement, et la prise de brief. Pas de logos empruntés."
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									role: "group",
									"aria-label": "Filtrer les projets",
									children: disciplines.map((item) => {
										const active = filter === item;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": active,
											onClick: () => setFilter(item),
											className: active ? "min-h-11 border border-ink bg-ink px-4 text-sm text-paper" : "min-h-11 border border-line px-4 text-sm text-ink",
											children: item
										}, item);
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-12 border-t border-ink",
								children: visible.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/projets/$slug",
									params: { slug: project.slug },
									className: "group grid gap-3 border-b border-line py-7 sm:grid-cols-12 sm:items-baseline sm:gap-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-serif text-2xl tabular-nums text-oxide sm:col-span-1",
											children: project.index
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sm:col-span-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-serif text-4xl leading-none",
												children: project.title
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted sm:col-span-5",
											children: project.summary
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center justify-between gap-3 text-sm sm:col-span-3 sm:justify-end",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: project.disciplines.join(" · ") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" })]
										})
									]
								}) }, project.slug))
							}),
							visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 text-muted",
								children: "Aucun projet dans cette sélection."
							}) : null
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "methode",
					className: "bg-ink text-paper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-5 py-16 lg:py-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-line",
								children: "Méthode"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 max-w-xl font-serif text-4xl leading-tight sm:text-5xl",
								children: "Quatre temps, dans cet ordre."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-4",
								children: method.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-serif text-3xl text-oxide",
										children: step.index
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-3 font-serif text-2xl",
										children: step.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-line",
										children: step.text
									})
								] }, step.index))
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "contact",
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-12 px-5 py-16 lg:grid-cols-12 lg:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "lg:col-span-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-widest text-muted",
									children: "Contact"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-serif text-4xl leading-tight sm:text-5xl",
									children: "Dites ce qu’il faut construire, et pour qui."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-muted",
									children: "Le formulaire prépare un courriel. Il n’enregistre rien. Vous pouvez aussi écrire directement."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${studio.email}`,
									className: "mt-6 inline-flex min-h-11 items-center font-serif text-2xl underline decoration-oxide decoration-2 underline-offset-4",
									children: studio.email
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-6 lg:col-start-7",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})
						})]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
	] });
}
function Practice({ title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "font-serif text-2xl",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3 flex flex-col",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
			className: "border-t border-line py-2 text-sm",
			children: item
		}, item))
	})] });
}
//#endregion
export { Home as component };
