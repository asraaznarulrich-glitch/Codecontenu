import { i as __toESM } from "../_runtime.mjs";
import { s as studio } from "./site-hychIQvj.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Menu, t as X } from "../_libs/lucide-react.mjs";
import { a as string, i as object, t as email } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-header-jTbAgO-B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var briefSchema = object({
	name: string().trim().min(2, "Indiquez votre nom."),
	email: email("Cette adresse n’est pas valide."),
	message: string().trim().min(20, "Décrivez le besoin en quelques phrases.").max(2e3, "Le message est trop long.")
});
var empty = {
	name: "",
	email: "",
	message: ""
};
function ContactForm({ subject = "Brief — Codecontenu", intro }) {
	const [values, setValues] = (0, import_react.useState)(empty);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ready, setReady] = (0, import_react.useState)(false);
	function update(key, value) {
		setValues((current) => ({
			...current,
			[key]: value
		}));
		setReady(false);
	}
	function onSubmit(event) {
		event.preventDefault();
		const parsed = briefSchema.safeParse({
			...values,
			email: values.email.trim()
		});
		if (!parsed.success) {
			const next = {};
			for (const issue of parsed.error.issues) {
				const key = issue.path[0];
				if (key === "name" || key === "email" || key === "message") next[key] ??= issue.message;
			}
			setErrors(next);
			setReady(false);
			return;
		}
		setErrors({});
		const body = `Nom : ${parsed.data.name}\nEmail : ${parsed.data.email}\n\n${parsed.data.message}`;
		const href = `mailto:${studio.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
		window.location.href = href;
		setReady(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		noValidate: true,
		className: "flex flex-col gap-5",
		children: [
			intro ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: intro
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "nom",
				label: "Nom",
				value: values.name,
				error: errors.name,
				autoComplete: "name",
				onChange: (value) => update("name", value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				id: "email",
				label: "Email",
				type: "email",
				value: values.email,
				error: errors.email,
				autoComplete: "email",
				onChange: (value) => update("email", value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "message",
						className: "text-sm",
						children: "Message"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "message",
						name: "message",
						rows: 6,
						value: values.message,
						"aria-invalid": errors.message ? true : void 0,
						"aria-describedby": errors.message ? "message-erreur" : void 0,
						onChange: (event) => update("message", event.target.value),
						className: "min-h-36 resize-y border border-line bg-paper px-3 py-3 text-ink outline-none"
					}),
					errors.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						id: "message-erreur",
						className: "text-sm text-oxide",
						children: errors.message
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Contexte, public, délai. Pas besoin d’un cahier des charges."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "inline-flex min-h-11 items-center justify-center bg-oxide px-5 text-sm text-paper transition-colors duration-200 hover:bg-oxide-deep",
					children: "Préparer le courriel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Ouvre votre messagerie vers ",
						studio.email,
						". Rien n’est stocké ici."
					]
				})]
			}),
			ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				role: "status",
				children: [
					"Le courriel est prêt. S’il ne s’est pas ouvert, écrivez directement à ",
					studio.email,
					"."
				]
			}) : null
		]
	});
}
function Field({ id, label, value, error, onChange, type = "text", autoComplete }) {
	const errorId = `${id}-erreur`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: id,
				className: "text-sm",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				name: id,
				type,
				value,
				autoComplete,
				"aria-invalid": error ? true : void 0,
				"aria-describedby": error ? errorId : void 0,
				onChange: (event) => onChange(event.target.value),
				className: "min-h-11 border border-line bg-paper px-3 text-ink outline-none"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: errorId,
				className: "text-sm text-oxide",
				children: error
			}) : null
		]
	});
}
var links = [
	{
		hash: "studio",
		label: "Studio"
	},
	{
		hash: "projets",
		label: "Projets"
	},
	{
		hash: "methode",
		label: "Méthode"
	},
	{
		hash: "contact",
		label: "Contact"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 border-b border-line bg-paper/95 backdrop-blur-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-serif text-xl leading-none tracking-tight",
					children: ["Code", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "italic text-oxide",
						children: "contenu"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 md:flex",
					"aria-label": "Sections",
					children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						hash: link.hash,
						activeOptions: { includeHash: true },
						className: "text-sm text-muted transition-colors duration-200 hover:text-ink",
						children: link.label
					}, link.hash))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					hash: "contact",
					className: "hidden min-h-11 items-center bg-oxide px-4 text-sm text-paper transition-colors duration-200 hover:bg-oxide-deep md:inline-flex",
					children: "Écrire"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center md:hidden",
					"aria-expanded": open,
					"aria-controls": "menu-mobile",
					onClick: () => setOpen((value) => !value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: open ? "Fermer le menu" : "Ouvrir le menu"
					}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "menu-mobile",
			className: "border-t border-line px-5 py-2 md:hidden",
			"aria-label": "Sections",
			children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				hash: link.hash,
				activeOptions: { includeHash: true },
				className: "flex min-h-11 items-center text-base",
				onClick: () => setOpen(false),
				children: link.label
			}, link.hash))
		}) : null]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-3 px-5 py-8 text-sm text-muted sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Codecontenu · Studio indépendant" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: `mailto:${studio.email}`,
				className: "text-ink underline decoration-line underline-offset-4",
				children: studio.email
			})]
		})
	});
}
//#endregion
export { SiteFooter as n, SiteHeader as r, ContactForm as t };
